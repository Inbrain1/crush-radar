// lib/routes/app_router.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../core/providers/auth_state_provider.dart';
import '../features/auth/presentation/login_page.dart';
import '../features/auth/presentation/register_page.dart';
import '../ui/pages/home_page.dart';
import '../utils/go_router_refresh_stream.dart';
final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateChangesProvider);

  return GoRouter(
    initialLocation: '/',
    refreshListenable: GoRouterRefreshStream(
      ref.watch(authStateChangesProvider.stream),
    ),
    routes: [
      GoRoute(
        path: '/',
        builder: (_, __) => const Scaffold(
          body: Center(child: CircularProgressIndicator()),
        ),
      ),
      GoRoute(
        path: '/login',
        builder: (_, __) => const LoginPage(),
      ),
      GoRoute(
        path: '/home',
        builder: (_, __) => const HomePage(),
      ),
      GoRoute(
        path: '/register',
        builder: (_, __) => const RegisterPage(),
      ),
    ],
      redirect: (context, state) {
        final user = authState.asData?.value;
        final loggingIn = state.matchedLocation == '/login';
        final registering = state.matchedLocation == '/register';

        if (authState.isLoading) return null; // ⏳ Esperar carga

        if (user == null) {
          // Si no está logueado, solo permitimos login o register
          return (loggingIn || registering) ? null : '/login';
        } else {
          // Si está logueado, evitar volver a login o register
          return (loggingIn || registering) ? '/home' : null;
        }
      }
  );
});