import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/auth_repository.dart';

final authControllerProvider = Provider<AuthController>((ref) {
  final authRepo = ref.watch(authRepositoryProvider);
  return AuthController(authRepository: authRepo);
});

class AuthController {
  final AuthRepository authRepository;

  AuthController({required this.authRepository});

  Future<void> signUp({
    required String email,
    required String password,
    required String name,
    required String gender,
    required int age,
    required String location,
    required String orientation,
    required List<String> interests,
  }) async {
    await authRepository.signUp(
      email: email,
      password: password,
      name: name,
      gender: gender,
      age: age,
      location: location,
      orientation: orientation,
      interests: interests,
    );
  }

  Future<void> login({
    required String email,
    required String password,
  }) async {
    await authRepository.login(email: email, password: password);
  }

  Future<void> logout() async {
    await authRepository.logout();
  }
}
