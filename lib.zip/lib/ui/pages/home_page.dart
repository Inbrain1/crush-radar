import 'package:flutter/material.dart';
import '../widgets/radar.dart';
import '../widgets/profile_card.dart';
import '../../services/fake_profile_generator.dart';
import '../../data/models/crush_profile.dart';
import '../pages/chat_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<CrushProfile> nearbyProfiles = [];

  void _scanRadar() {
    setState(() {
      nearbyProfiles = FakeProfileGenerator.generateFakeProfiles(3);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Money Porciaca'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          const Expanded(
            flex: 3,
            child: RadarWidget(),
          ),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: _scanRadar,
            icon: const Icon(Icons.radar),
            label: const Text('Escanear alrededor'),
          ),
          const SizedBox(height: 10),
          Expanded(
            flex: 2,
            child: ListView.builder(
              itemCount: nearbyProfiles.length,
              itemBuilder: (context, index) {
                return ProfileCard(
                  profile: nearbyProfiles[index],
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChatPage(crushName: nearbyProfiles[index].name),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}